
1. The data loading methods are located in the "data" folder, with two files corresponding to different datasets' loading.
2. The main folder contains the experimental code, including NBDT, CNN_LSTM; State_former, and eMem-NDT.
3. All of our models are stored in the "model" folder.
4. The visualization of memory usage and the retrieval of the NBDT tree structure files are all saved in the "information" folder.
